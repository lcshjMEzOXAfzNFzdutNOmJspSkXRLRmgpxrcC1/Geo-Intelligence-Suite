import os
import uuid
import requests as http_requests
from flask import Flask, request, jsonify, render_template
from utils.exif_extractor import get_gps_coords
from utils.ip_lookup import lookup_ip
from utils.geocode import geocode_address, reverse_geocode
from utils.ollama_vision import analyze_image, list_models

app = Flask(__name__)

UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")
ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png", "tiff", "tif", "heic", "webp"}
MAX_CONTENT_LENGTH = 32 * 1024 * 1024

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH

os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _process_image(temp_path, label, use_ollama=False, ollama_model="moondream"):
    coords, exif_error = get_gps_coords(temp_path)

    result = {"label": label}

    if coords:
        result["lat"] = coords["lat"]
        result["lon"] = coords["lon"]
        result["source"] = "exif"

        location_info, _ = reverse_geocode(coords["lat"], coords["lon"])
        if location_info:
            result["display_name"] = location_info["display_name"]
            result["city"] = location_info["city"]
            result["country"] = location_info["country"]
        else:
            result["display_name"] = f"{coords['lat']:.6f}, {coords['lon']:.6f}"
            result["city"] = ""
            result["country"] = ""
    else:
        result["exif_error"] = exif_error

    if use_ollama:
        analysis, ollama_error = analyze_image(temp_path, model=ollama_model)
        if analysis:
            result["ollama_analysis"] = analysis
            result["ollama_model"] = ollama_model
        else:
            result["ollama_error"] = ollama_error

    if "lat" not in result and "ollama_analysis" not in result:
        return None, exif_error or "No GPS data and Ollama analysis unavailable"

    return result, None


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/ollama/models", methods=["GET"])
def get_ollama_models():
    models, error = list_models()
    return jsonify({"models": models, "error": error})


@app.route("/upload", methods=["POST"])
def upload_image():
    if "image" not in request.files:
        return jsonify({"error": "No image file provided"}), 400

    file = request.files["image"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    if not allowed_file(file.filename):
        return jsonify({"error": "File type not allowed. Use JPG, PNG, TIFF, or WebP."}), 400

    use_ollama = request.form.get("use_ollama", "false").lower() == "true"
    ollama_model = request.form.get("ollama_model", "moondream")

    ext = file.filename.rsplit(".", 1)[1].lower()
    temp_filename = f"{uuid.uuid4().hex}.{ext}"
    temp_path = os.path.join(app.config["UPLOAD_FOLDER"], temp_filename)

    try:
        file.save(temp_path)
        result, error = _process_image(
            temp_path, file.filename, use_ollama=use_ollama, ollama_model=ollama_model
        )
        if error:
            return jsonify({"error": error}), 400
        result["input_type"] = "file"
        return jsonify(result)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


@app.route("/upload-url", methods=["POST"])
def upload_from_url():
    data = request.get_json(silent=True) or {}
    url = data.get("url", "").strip()
    use_ollama = data.get("use_ollama", False)
    ollama_model = data.get("ollama_model", "moondream")

    if not url:
        return jsonify({"error": "No image URL provided"}), 400

    if not url.startswith(("http://", "https://")):
        return jsonify({"error": "URL must start with http:// or https://"}), 400

    try:
        headers = {"User-Agent": "GeoIntelligenceSuite/1.0"}
        resp = http_requests.get(url, headers=headers, timeout=20, stream=True)
        resp.raise_for_status()

        content_type = resp.headers.get("Content-Type", "").lower()
        url_clean = url.split("?")[0].lower()

        if "jpeg" in content_type or "jpg" in content_type or url_clean.endswith((".jpg", ".jpeg")):
            ext = "jpg"
        elif "png" in content_type or url_clean.endswith(".png"):
            ext = "png"
        elif "tiff" in content_type or url_clean.endswith((".tiff", ".tif")):
            ext = "tiff"
        elif "webp" in content_type or url_clean.endswith(".webp"):
            ext = "webp"
        else:
            ext = "jpg"

        temp_filename = f"{uuid.uuid4().hex}.{ext}"
        temp_path = os.path.join(app.config["UPLOAD_FOLDER"], temp_filename)

        size = 0
        with open(temp_path, "wb") as f:
            for chunk in resp.iter_content(chunk_size=8192):
                size += len(chunk)
                if size > MAX_CONTENT_LENGTH:
                    raise ValueError("Image too large (max 32 MB)")
                f.write(chunk)

    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": f"Failed to download image: {str(e)}"}), 400

    try:
        result, error = _process_image(
            temp_path, url, use_ollama=use_ollama, ollama_model=ollama_model
        )
        if error:
            return jsonify({"error": error}), 400
        result["input_type"] = "url"
        result["url"] = url
        return jsonify(result)
    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


@app.route("/ip", methods=["POST"])
def ip_lookup():
    data = request.get_json(silent=True) or {}
    ip_address = data.get("ip", "").strip()

    if not ip_address:
        return jsonify({"error": "No IP address provided"}), 400

    result, error = lookup_ip(ip_address)
    if error:
        return jsonify({"error": error}), 400

    result["source"] = "ip"
    return jsonify(result)


@app.route("/search", methods=["POST"])
def search_address():
    data = request.get_json(silent=True) or {}
    address = data.get("address", "").strip()

    if not address:
        return jsonify({"error": "No address provided"}), 400

    result, error = geocode_address(address)
    if error:
        return jsonify({"error": error}), 400

    result["source"] = "search"
    return jsonify(result)


@app.route("/reverse", methods=["POST"])
def reverse_geo():
    data = request.get_json(silent=True) or {}
    try:
        lat = float(data.get("lat"))
        lon = float(data.get("lon"))
    except (TypeError, ValueError):
        return jsonify({"error": "Invalid lat/lon values"}), 400

    result, error = reverse_geocode(lat, lon)
    if error:
        return jsonify({"error": error}), 400

    result["lat"] = lat
    result["lon"] = lon
    result["source"] = "reverse"
    return jsonify(result)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
