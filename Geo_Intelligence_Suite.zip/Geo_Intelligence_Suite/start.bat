@echo off
setlocal enabledelayedexpansion
title Geo Intelligence Suite - Launcher
color 0A

echo.
echo  ============================================================
echo   GEO INTELLIGENCE SUITE - Auto Launcher
echo   C2 Geo-Locator Tool with Ollama AI Vision
echo  ============================================================
echo.

REM ─── STEP 1: Check Python ─────────────────────────────────────
echo [1/6] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [ERROR] Python is not installed or not in PATH.
    echo  Download Python 3.8+ from: https://www.python.org/downloads/
    echo  Make sure to check "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)
for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYVER=%%i
echo  [OK] %PYVER% found.

REM ─── STEP 2: Create virtual environment ───────────────────────
echo.
echo [2/6] Setting up virtual environment...

if not exist ".venv" (
    echo  Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo  [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
    echo  [OK] Virtual environment created at .venv\
) else (
    echo  [OK] Virtual environment already exists.
)

REM ─── STEP 3: Activate venv & install requirements ─────────────
echo.
echo [3/6] Installing Python dependencies...

call .venv\Scripts\activate.bat
if errorlevel 1 (
    echo  [ERROR] Failed to activate virtual environment.
    pause
    exit /b 1
)

pip install -r requirements.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo  [ERROR] Failed to install requirements.
    echo  Try running manually: pip install -r requirements.txt
    pause
    exit /b 1
)
echo  [OK] All Python packages installed.

REM ─── STEP 4: Check Ollama ─────────────────────────────────────
echo.
echo [4/6] Checking Ollama installation...

ollama --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo  [WARNING] Ollama is not installed or not in PATH.
    echo.
    echo  Ollama is required for AI Scene Analysis (optional feature).
    echo  Download it from: https://ollama.com/download
    echo.
    echo  After installing Ollama, re-run this script.
    echo  The app will still work without Ollama (EXIF + IP + Search).
    echo.
    set OLLAMA_AVAILABLE=0
    goto :start_ollama_skip
)

for /f "tokens=*" %%i in ('ollama --version 2^>^&1') do set OLLAMA_VER=%%i
echo  [OK] Ollama %OLLAMA_VER% found.
set OLLAMA_AVAILABLE=1

REM ─── STEP 5: Start Ollama server ──────────────────────────────
echo.
echo [5/6] Starting Ollama server...

REM Check if Ollama is already running
curl -s http://localhost:11434 >nul 2>&1
if not errorlevel 1 (
    echo  [OK] Ollama server is already running.
    goto :check_model
)

echo  Starting Ollama server in background...
start /min "Ollama Server" cmd /c "ollama serve"

REM Wait for Ollama to start (up to 15 seconds)
set /a tries=0
:wait_ollama
timeout /t 2 /nobreak >nul
curl -s http://localhost:11434 >nul 2>&1
if not errorlevel 1 goto :ollama_ready
set /a tries+=1
if !tries! lss 7 (
    echo  Waiting for Ollama to start... (!tries!/7^)
    goto :wait_ollama
)
echo  [WARNING] Ollama server did not respond in time. AI features may not work.
goto :start_ollama_skip

:ollama_ready
echo  [OK] Ollama server is running on http://localhost:11434

REM ─── STEP 5b: Check and pull vision model ─────────────────────
:check_model
echo.
echo  Checking for vision models...

set DEFAULT_MODEL=moondream
set MODEL_FOUND=0

ollama list 2>nul | findstr /i "moondream" >nul 2>&1
if not errorlevel 1 (
    echo  [OK] moondream is installed.
    set MODEL_FOUND=1
    set DEFAULT_MODEL=moondream
    goto :start_ollama_skip
)

ollama list 2>nul | findstr /i "llava" >nul 2>&1
if not errorlevel 1 (
    echo  [OK] llava is installed.
    set MODEL_FOUND=1
    set DEFAULT_MODEL=llava
    goto :start_ollama_skip
)

if !MODEL_FOUND! == 0 (
    echo.
    echo  No vision model found. Installing moondream (fastest, ~1.8GB^)...
    echo  This is a one-time download. Please wait.
    echo.
    ollama pull moondream
    if errorlevel 1 (
        echo  [WARNING] Failed to download moondream.
        echo  Try manually: ollama pull moondream
        echo  Or try:       ollama pull llava
    ) else (
        echo  [OK] moondream installed successfully.
        set DEFAULT_MODEL=moondream
    )
)

:start_ollama_skip

REM ─── STEP 6: Launch Flask App ─────────────────────────────────
echo.
echo [6/6] Launching Geo Intelligence Suite...
echo.
echo  ============================================================
echo   App running at: http://localhost:5000
echo   Ollama AI at:   http://localhost:11434
echo.
echo   Press Ctrl+C in this window to stop the app.
echo  ============================================================
echo.

REM Open browser after a short delay
start /b "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:5000"

REM Start Flask
python app.py

REM Cleanup on exit
echo.
echo  App stopped. Deactivating environment...
call .venv\Scripts\deactivate.bat 2>nul
echo  Done.
pause
