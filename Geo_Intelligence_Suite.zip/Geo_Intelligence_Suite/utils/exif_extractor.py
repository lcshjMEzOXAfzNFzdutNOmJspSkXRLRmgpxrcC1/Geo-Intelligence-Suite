from PIL import Image, ExifTags


def _convert_to_decimal(value):
    degrees = float(value[0])
    minutes = float(value[1])
    seconds = float(value[2])
    return degrees + (minutes / 60.0) + (seconds / 3600.0)


def get_gps_coords(image_path):
    try:
        img = Image.open(image_path)
        exif_data = img._getexif()
        if not exif_data:
            return None, "No EXIF data found in image"

        gps_info = {}
        for tag_id, value in exif_data.items():
            tag = ExifTags.TAGS.get(tag_id, tag_id)
            if tag == "GPSInfo":
                for gps_tag_id, gps_value in value.items():
                    gps_tag = ExifTags.GPSTAGS.get(gps_tag_id, gps_tag_id)
                    gps_info[gps_tag] = gps_value

        if not gps_info:
            return None, "No GPS data found in image EXIF"

        lat_data = gps_info.get("GPSLatitude")
        lon_data = gps_info.get("GPSLongitude")
        lat_ref = gps_info.get("GPSLatitudeRef", "N")
        lon_ref = gps_info.get("GPSLongitudeRef", "E")

        if not lat_data or not lon_data:
            return None, "Incomplete GPS data in image"

        lat = _convert_to_decimal(lat_data)
        lon = _convert_to_decimal(lon_data)

        if lat_ref == "S":
            lat = -lat
        if lon_ref == "W":
            lon = -lon

        return {"lat": lat, "lon": lon}, None

    except Exception as e:
        return None, f"Error reading image: {str(e)}"
