import base64
import requests

OLLAMA_URL = "http://localhost:11434"

RECOMMENDED_MODELS = [
    "moondream",
    "llava",
    "llava:7b",
    "llava-phi3",
    "minicpm-v",
]

LOCATION_PROMPT = (
    "You are a geo-intelligence analyst. Examine this image carefully and identify "
    "any geographic location clues. Look for: visible street signs, shop names, "
    "landmarks or monuments, architectural style, vegetation and terrain type, "
    "license plate regions, flags or national symbols, language on any text, "
    "weather/climate indicators, and any other visual context. "
    "Provide a concise, structured analysis of the most likely location or region "
    "where this photo was taken. If you can narrow it down to a city or country, do so."
)


def list_models():
    try:
        resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=5)
        if resp.status_code == 200:
            models = [m["name"] for m in resp.json().get("models", [])]
            return models, None
        return [], f"Ollama returned status {resp.status_code}"
    except requests.ConnectionError:
        return [], "Ollama not running. Start with: ollama serve"
    except Exception as e:
        return [], str(e)


def analyze_image(image_path, model="moondream"):
    try:
        with open(image_path, "rb") as f:
            image_b64 = base64.b64encode(f.read()).decode("utf-8")

        resp = requests.post(
            f"{OLLAMA_URL}/api/chat",
            json={
                "model": model,
                "messages": [
                    {
                        "role": "user",
                        "content": LOCATION_PROMPT,
                        "images": [image_b64],
                    }
                ],
                "stream": False,
            },
            timeout=90,
        )

        if resp.status_code == 404:
            return None, f"Model '{model}' not found. Pull it with: ollama pull {model}"
        if resp.status_code != 200:
            return None, f"Ollama error: HTTP {resp.status_code}"

        content = resp.json().get("message", {}).get("content", "").strip()
        if not content:
            return None, "Ollama returned an empty response"

        return content, None

    except requests.ConnectionError:
        return None, "Ollama is not running. Start it with: ollama serve"
    except requests.Timeout:
        return None, "Ollama timed out (model may be loading — try again)"
    except Exception as e:
        return None, f"Ollama error: {str(e)}"
