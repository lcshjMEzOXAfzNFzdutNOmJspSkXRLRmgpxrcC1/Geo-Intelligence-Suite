import requests


def lookup_ip(ip_address):
    try:
        ip = ip_address.strip()
        if not ip:
            return None, "No IP address provided"

        url = f"http://ip-api.com/json/{ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query"
        response = requests.get(url, timeout=8)
        data = response.json()

        if data.get("status") == "fail":
            return None, data.get("message", "IP lookup failed")

        return {
            "ip": data.get("query", ip),
            "lat": data.get("lat"),
            "lon": data.get("lon"),
            "city": data.get("city", "Unknown"),
            "region": data.get("regionName", "Unknown"),
            "country": data.get("country", "Unknown"),
            "country_code": data.get("countryCode", ""),
            "zip": data.get("zip", ""),
            "timezone": data.get("timezone", ""),
            "isp": data.get("isp", "Unknown"),
            "org": data.get("org", ""),
            "as_info": data.get("as", ""),
        }, None

    except requests.Timeout:
        return None, "IP lookup timed out"
    except Exception as e:
        return None, f"IP lookup error: {str(e)}"
