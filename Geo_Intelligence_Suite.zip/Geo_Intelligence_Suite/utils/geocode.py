import requests
import time


_last_request_time = 0


def geocode_address(address):
    global _last_request_time

    if not address or not address.strip():
        return None, "No address provided"

    elapsed = time.time() - _last_request_time
    if elapsed < 1.1:
        time.sleep(1.1 - elapsed)

    try:
        url = "https://nominatim.openstreetmap.org/search"
        params = {
            "q": address.strip(),
            "format": "json",
            "limit": 1,
            "addressdetails": 1,
        }
        headers = {"User-Agent": "GeoIntelligenceSuite/1.0"}
        response = requests.get(url, params=params, headers=headers, timeout=8)
        _last_request_time = time.time()

        data = response.json()
        if not data:
            return None, f"No results found for: {address}"

        result = data[0]
        addr = result.get("address", {})
        display_name = result.get("display_name", address)

        city = (
            addr.get("city")
            or addr.get("town")
            or addr.get("village")
            or addr.get("county")
            or ""
        )
        country = addr.get("country", "")

        return {
            "lat": float(result["lat"]),
            "lon": float(result["lon"]),
            "display_name": display_name,
            "city": city,
            "country": country,
            "type": result.get("type", ""),
            "importance": result.get("importance", 0),
        }, None

    except requests.Timeout:
        return None, "Geocoding request timed out"
    except Exception as e:
        return None, f"Geocoding error: {str(e)}"


def reverse_geocode(lat, lon):
    global _last_request_time

    elapsed = time.time() - _last_request_time
    if elapsed < 1.1:
        time.sleep(1.1 - elapsed)

    try:
        url = "https://nominatim.openstreetmap.org/reverse"
        params = {
            "lat": lat,
            "lon": lon,
            "format": "json",
            "addressdetails": 1,
        }
        headers = {"User-Agent": "GeoIntelligenceSuite/1.0"}
        response = requests.get(url, params=params, headers=headers, timeout=8)
        _last_request_time = time.time()

        data = response.json()
        if "error" in data:
            return None, data["error"]

        addr = data.get("address", {})
        city = (
            addr.get("city")
            or addr.get("town")
            or addr.get("village")
            or addr.get("county")
            or ""
        )
        country = addr.get("country", "")
        display_name = data.get("display_name", f"{lat}, {lon}")

        return {
            "display_name": display_name,
            "city": city,
            "country": country,
            "address": addr,
        }, None

    except requests.Timeout:
        return None, "Reverse geocoding timed out"
    except Exception as e:
        return None, f"Reverse geocoding error: {str(e)}"
